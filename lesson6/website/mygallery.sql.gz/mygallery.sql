-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 14 2022 г., 08:53
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mygallery`
--

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE `feedback` (
  `id` int NOT NULL,
  `author` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Аnonymous user',
  `text` text COLLATE utf8mb4_general_ci,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`id`, `author`, `text`, `date`) VALUES
(13, 'Анонимный пользователь', 'Товары соответствуют описанию, быстрая доставка. Хороший магазин.', '2022-04-14 07:43:09'),
(14, 'Коля', 'Магазин понравился. Большой выбор. С ребятами можно иметь дело. Только веб - разработчика бы им))', '2022-04-14 07:46:52'),
(16, 'Евгений Онегин', 'Нормально!', '2022-04-14 07:51:55');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `price` float NOT NULL,
  `path` varchar(250) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `views` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `description`, `price`, `path`, `views`) VALUES
(34, 'Набор из 3 фильтров RayLab (UV,CPL,ND8) 58mm', 'Диаметр, мм:\r\n58\r\n\r\nКомплектация:\r\nнейтрально серый фильтр, ультрафиолетовый фильтр, поляризационный фильтр\r\n', 1700, '1584afaaab91a053f886446576313c592_thumb_4d76a05b13f4590.png', 11),
(35, 'Беззеркальный фотоаппарат Canon EOS R Body', 'Матрица\r\n\r\nРазрешение матрицы, Мпикс:\r\n30.3\r\n\r\nПолнокадровая матрица:\r\nЕсть\r\n\r\nФизический размер матрицы:\r\n36 x 24 мм\r\n\r\nТип матрицы:\r\nCMOS\r\n\r\nКроп-фактор:\r\n1\r\n\r\nМаксимальное разрешение:\r\n6720 x 4480\r\n\r\nЧувствительность:\r\n50 - 3200 ISO, Auto ISO\r\n', 207790, '2584afaaab91a053f886446576313c592_thumb_4d76a05b13f4590.png', 7),
(36, 'Карта памяти SanDisk SDXC Extreme Pro Class 10 UHS-I U3 (170/90MB/s) 64GB', 'Тип носителя: SDXC\r\nОбъем, Гб: 64\r\nКласс скорости: UHS-I', 4190, '3584afaaab91a053f886446576313c592_thumb_4d76a05b13f4590.png', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

CREATE TABLE `photos` (
  `id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `path` text COLLATE utf8mb4_general_ci NOT NULL,
  `size` int NOT NULL,
  `views` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `path`, `size`, `views`) VALUES
(73, 'QciIZ22uL.jpg', '../../../public/images/images_big/QciIZ22uL.jpg', 300999, 17),
(74, 'shar_el_novyiy_god_ball_spruce_new_year.jpg', '../../../public/images/images_big/shar_el_novyiy_god_ball_spruce_new_year.jpg', 407741, 6),
(75, 'el_ogni_sneg.jpg', '../../../public/images/images_big/el_ogni_sneg.jpg', 536871, 0),
(76, 'zima_rassvet_les_sklon_sneg.jpg', '../../../public/images/images_big/zima_rassvet_les_sklon_sneg.jpg', 818683, 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
